import React from 'react'
import { Link } from 'react-router-dom'

type Props = {}

export default function Error({}: Props) {
  return (
    <div className="text-center d-flex align-items-center justify-content-center my-div">
      <h1 className='text-orange'>
        Грешка 404. Врати се назад на <Link to="/" className='text-orange'>почетна</Link>
      </h1>
    </div>

  )
}