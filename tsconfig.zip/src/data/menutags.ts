export const MenuTags =[
    {
        img: '../images/Corba.png',
        tag: 'Чорби'
    },
    {
        img: '../images/Salati.png',
        tag: 'Салати'
    },
    {
        img: '../images/Veganska.png',
        tag: 'Веганска'
    },
    {
        img: '../images/Burger.png',
        tag: 'Бургер'
    },
    {
        img: '../images/Domashni proizvodi.png',
        tag: 'Оброк'
    },
    {
        img: '../images/Corba.png',
        tag: 'Чорби'
    },
    {
        img: '../images/Burger.png',
        tag: 'Домашни производи'
    },
    {
        img: '../images/Corba.png',
        tag: 'Чорби'
    },
    {
        img: '../images/Salati.png',
        tag: 'Салати'
    },
    {
        img: '../images/Veganska.png',
        tag: 'Веганска'
    },
    {
        img: '../images/Burger.png',
        tag: 'Бургер'
    },
    {
        img: '../images/Domashni proizvodi.png',
        tag: 'Оброк'
    },
    {
        img: '../images/Corba.png',
        tag: 'Чорби'
    },
    {
        img: '../images/Burger.png',
        tag: 'Домашни производи'
    },
]


