export const ScoresData = [
    {
        img: '../images/Untitled-1lllll 1.png',
        number: "10 900+ ",
        desc: 'задоволни клиенти'

    },
    {
        img: '../images/Untitled-hhhh 1.png',
        number: '13 765+ ',
        desc: 'подготвени јадења'

    },
    {
        img: '../images/hat 1.png',
        number: '864+ ',
        desc: 'среќни готвачи.'
    },

]
