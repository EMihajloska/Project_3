export const MealsData = [
    {
        img:'../images/GreenSalad.png',
        cookphoto:'../images/Ellipse 7.png',
        title: 'Салата со брокули',
        price: '300 ден',
        raiting: '4',
        distance: '300м '

    },
    {
        img:'../images/MeatAndPotates.png',
        cookphoto:'../images/Ellipse 7 (1).png',
        title: 'Скара и компири',
        price: '300 ден',
        raiting: '4',
        distance: '300м '

    },
    {
        img:'../images/Meat.png',
        cookphoto:'../images/Ellipse 7 (2).png',
        title: 'Ќофтиња',
        price: '300 ден',
        raiting: '4',
        distance: '300м '

    },
    {
        img:'../images/GreenSalad.png',
        cookphoto:'../images/Ellipse 7.png',
        title: 'Салата со брокули',
        price: '300 ден',
        raiting: '4',
        distance: '300м '

    },
    {
        img:'../images/MeatAndPotates.png',
        cookphoto:'../images/Ellipse 7 (1).png',
        title: 'Скара и компири',
        price: '300 ден',
        raiting: '4',
        distance: '300м '

    },
    {
        img:'../images/Meat.png',
        cookphoto:'../images/Ellipse 7 (2).png',
        title: 'Ќофтиња',
        price: '300 ден',
        raiting: '4',
        distance: '300м '

    },
    {
        img:'../images/GreenSalad.png',
        cookphoto:'../images/Ellipse 7.png',
        title: 'Салата со брокули',
        price: '300 ден',
        raiting: '4',
        distance: '300м '

    },
    {
        img:'../images/MeatAndPotates.png',
        cookphoto:'../images/Ellipse 7 (1).png',
        title: 'Скара и компири',
        price: '300 ден',
        raiting: '4',
        distance: '300м '

    },
    {
        img:'../images/Meat.png',
        cookphoto:'../images/Ellipse 7 (2).png',
        title: 'Ќофтиња',
        price: '300 ден',
        raiting: '4',
        distance: '300м '

    }
    
]