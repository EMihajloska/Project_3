export const OurValuesData = [
    
    {
        img: '../images/Ellipse 81.png',
        title: 'Поврзување !',
        desc: 'Вистински луѓе. Автентична љубов'

    },
    {
        img: '../images/Ellipse 81 (1).png',
        title: 'Споделување на радост !',
        desc: 'Уживајте во заедницата преку храна.'

    },
    {
        img: '../images/Ellipse 82.png',
        title: 'Кулинарски можности !',
        desc: 'Зајакнување на домашните готвачи.'
    },
    

]

