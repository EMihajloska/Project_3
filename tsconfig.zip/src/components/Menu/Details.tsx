const Details = (props:any) => {
    return <div>{props.data}</div>;
  };
  
  export default Details;