export const AccordionData = [
    
    {
        title: '1. Како да се регистрирам?',
        content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In lacus ligula, suscipit sed suscipit sit amet, tristique sed sapien. Vivamus pellentesque nibh neque, vel placerat sapien hendrerit vel.'
    },
    {
        title: ' 2. Како да променам коментар?',
        content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In lacus ligula, suscipit sed suscipit sit amet, tristique sed sapien. Vivamus pellentesque nibh neque, vel placerat sapien hendrerit vel.'
    },
    {
        title: '3. Како да променам веќе објавена слика на рецепт?',
        content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In lacus ligula, suscipit sed suscipit sit amet, tristique sed sapien. Vivamus pellentesque nibh neque, vel placerat sapien hendrerit vel.'
    },
    {
        title: '4. Како да променам веќе објавена слика на рецепт?',
        content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In lacus ligula, suscipit sed suscipit sit amet, tristique sed sapien. Vivamus pellentesque nibh neque, vel placerat sapien hendrerit vel.'
    },
    {
        title: '5. Како да променам веќе објавена слика на рецепт?',
        content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In lacus ligula, suscipit sed suscipit sit amet, tristique sed sapien. Vivamus pellentesque nibh neque, vel placerat sapien hendrerit vel.'
    },

]
