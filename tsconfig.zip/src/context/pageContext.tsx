import { createContext, useEffect, useState } from "react";
import { CookType } from "../types/types";
import { useParams } from "react-router-dom";

type ContextData = { cooks: CookType[] };

type Props = {
  children: React.ReactNode;
};

export const Context = createContext({} as ContextData);

export const Provider = ({ children }: Props) => {
  const [cooks, setCooks] = useState<CookType[]>([]);
  const {singleCook} = useParams()
  console.log(singleCook)

  useEffect(() => {
    fetch("http://localhost:5001/cookData")
      .then((res) => res.json())
      .then((data) => setCooks(data));
  }, []);
console.log(cooks)



  const contextDataObj = {
    cooks,
  };

  return <Context.Provider value={contextDataObj}>{children}</Context.Provider>;
};
