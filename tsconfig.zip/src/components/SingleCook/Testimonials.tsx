import React from "react";
// import { Pagination } from "react-bootstrap";
// import ReactPaginate from "react-paginate";

type Props = {
  test: any;
};

export default function MenuSingleCook({ test }: Props) {
  return (
  
      <div className="col-md-4 text-center d-flex align-self-strech">
        <div className="card">
          <div className="card-body">
            <h6 className="card-title text-shadow">{test.name}</h6>
            <p className="card-text text-justify font-sm">{test.desc}</p>
          </div>
        </div>
      </div>
  
  );
}
