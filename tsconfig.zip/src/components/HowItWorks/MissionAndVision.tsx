import React from "react";
import { OurValuesData } from "../../data/cards";
import { MissonAndVisionData } from "../../data/missonandvision";



type Props = {
  // img?: string;
  // title?: string;
  // desc?: string;
};

export default function MissionAndVision({}: Props) {
  return (
    <div className="container">
      {/* <h2 className="text-center">Нашата мисија и визија</h2> */}
      <div className="row d-flex justify-content-center text-center my-5">
            <div className="col-md-3"><hr className="hr-orange"/></div>
   <div className="col-md-4">       <h2 className="text-shadow">Нашата мисија и визија</h2></div>
          <div className="col-md-3"><hr className="hr-orange"/></div>
          </div>
      <div className="row justify-content-center align-items-center text-center">
        {MissonAndVisionData.map((el) => (
          <div className="col-lg-4 ">
            <img src={el.img} alt="" className="img-fluid"/>
            <h4 className="mt-3">{el.title}</h4>
            <p className="f-5">{el.desc}</p>
          </div>
        ))}

      </div>
    </div>
  );
}