import { Delivery } from "../types/types";

const data: Delivery[] = [
    {
        id: 1,
        cookId: 2,
        numberOfDeliveries: 25
    },
    {
        id: 2,
        cookId: 1,
        numberOfDeliveries: 2
    },
]

export default data;
