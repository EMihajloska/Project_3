export type CookType = {
  id: number;
  name: string;
  imageUrl: string;
  thumbnailImageUrl: string;
  rating: number;
  cuisines: string[];
  location: string;
  price?: string;
  loc?: {
    lat: string;
    lan: string;
  };
  recipes: {
    id: number;
    isOrderable?: boolean;
    img: string;
    title: string;
    price: string;
    raiting: string;
    desc: string;
    prepTime: string;
    dates: string[];
  }[];
};

export type Delivery = {
  id: number;
  cookId: number;
  numberOfDeliveries: number;
};

export type Recipe = {};

export type TestimonialType = {
  id: number;
  name: string;
  desc: string;
};
