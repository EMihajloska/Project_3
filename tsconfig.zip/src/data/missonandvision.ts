export const MissonAndVisionData = [
    
    {
        img: '../images/Rectangle 346 (2).png',
        title: 'Поврзување !',
        desc: 'Вистински луѓе. Автентична љубов'

    },
    {
        img: '../images/Rectangle 347 (2).png',
        title: 'Споделување на радост !',
        desc: 'Уживајте во заедницата преку храна.'

    },
    {
        img: '../images/Rectangle 348-2.jpg',
        title: 'Кулинарски можности !',
        desc: 'Зајакнување на домашните готвачи.'
    },
    

]
