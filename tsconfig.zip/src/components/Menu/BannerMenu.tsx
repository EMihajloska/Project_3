import React from "react";
import Carousel from "react-multi-carousel";


import "react-multi-carousel/lib/styles.css";
import { MenuTags } from "../../data/menutags";

type Props = {};

export default function BannerMenu({}: Props) {
  const responsive = {

    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 6,
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 2,
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 1,
    },
  };
  return (
    <div className="container text-center">
      {/* <h2>Мени</h2> */}
      <div className="row d-flex justify-content-center text-center my-5">
          <div className="col-md-3">
            <hr className="hr-orange" />
          </div>
          <div className="col-md-2">
            {" "}
            <h2 className="text-shadow">Мени</h2>
          </div>
          <div className="col-md-3">
            <hr className="hr-orange" />
          </div>
        </div>


      <Carousel responsive={responsive}>
        {MenuTags.map((el) => (
          <div className="d-flex align-items-center ">
            <img src={el.img} alt="" className="icons mr-2 "/>
            <div>{el.tag}</div>
          </div>
        ))}
      </Carousel>
      
    </div>
  );
}
